Dobre Grigore Adelin 343C4

Tema 1 IOC

Tehnologii folosite:
	BootStrap - interfata grafica
	NodeJS - server express
 
Api-uri apelate: Google Maps
		 Plotly Charts
		 WattTime 
		 OpenWeatherMaps

